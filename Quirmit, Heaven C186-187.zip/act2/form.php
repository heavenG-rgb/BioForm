<!DOCTYPE html>
<html>
<head>
	<title>Activity 2</title>
</head>
<link rel="stylesheet" type="text/css" href="style.css">
<body>
	<h1>BIODATA</h1>
	<form action="" method="POST">
		<div class="form">
		Name: <input type="text" name="name">
		
		Present Adress: <input type="text" name="prAdd">

		
		Permanent Address: <input type="text" name="pAdd">
		<br>
		Date of Birth: <input type="text" name="Dbirth">
		
		Religion: <input type="text" name="Religion">
		<br>

		Civil Status: <input type="text" name="Cstatus">
		
		Age:   <input type="age" name="age">
		<br>
		
		Citizenship: <input type="text" name="Citizenship">
		
		Weight: <input type="text" name="Weight">
		<br>

		
		Place of Birth: <input type="text" name="POBirth">
		
		Height<input type="text" name="height">
		<br>
		
		Name of Father: <input type="text" name="NOfather">
		<br>
		
		Name of Mother: <input type="text" name="NOMother">
		<br>

		
		Address: <input type="text" name="adress">
		<br>
		
		Language or Dialect Spoken: <input type="text" name="Language">
		<br>
		
		Person to be notified In Case of Emergency: <input type="text" name="emergency">
	</div>

	<h2>EDUCATIONAL BACKGROUND:</h2>

	Elementary: <input type="text" name="Elementary">
	Year Graduated: <input type="text" name="YEGraduate">
	High School: <input type="text" name="highschool">
	Year Graduate: <input type="text" name="YhGraduate">
	College: <input type="text" name="college">
	Year Graduate: <input type="text" name="YcGraduate">
	Course: <input type="text" name="course">
	Special Skills: <input type="text" name="sskills">


	<input type="submit" name="submit" >
	
	</form>

	<?php
	if (isset($_POST['submit'])) {
		$name=$_POST['name'];
		$PresentAdress=$_POST['prAdd'];
		$PermanentAdress=$_POST['pAdd'];
		$Dbirth=$_POST['Dbirth'];
		$religion=$_POST['Religion'];
		$Cstatus=$_POST['Cstatus'];
		$age=$_POST['age'];
		$Citizenship=$_POST['Citizenship'];
		$Weight=$_POST['Weight'];
		$Pobirths=$_POST['POBirth'];
		$height=$_POST['height'];
		$nofather=$_POST['NOfather'];
		$nomother=$_POST['NOMother'];
		$adress=$_POST['adress'];
		$emergency=$_POST['emergency'];
		$Language=$_POST['Language'];
		$elementary=$_POST['Elementary'];
		$YEgraduate=$_POST['YEGraduate'];
		$highschool=$_POST['highschool'];
		$Yhgraduate=$_POST['YhGraduate'];
		$college=$_POST['college'];
		$YCgraduate=$_POST['YcGraduate'];
		$course=$_POST['course'];
		$skills=$_POST['sskills'];

		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<p class='color'>Record Successful</p>";
		echo "<br>";
		echo "Name:".$name." ";
		echo "<br>";
		echo "<br>";
		echo "Present Adress ".$PresentAdress." ";
		echo "<br>";
		echo "<br>";
		echo "Permanent Adress: ".$PermanentAdress." ";
		echo "<br>";
		echo "<br>";
		echo "Date Of Birht: ".$Dbirth." ";
		echo "<br>";
		echo "<br>";
		echo "Religion: ".$religion." ";
		echo "<br>";
		echo "<br>";
		echo "Civil Status      :".$Cstatus." "."         Age:".$age;
		echo "<br>";
		echo "<br>";
		echo "Citizenship      :".$Citizenship." "."              Weight:".$Weight;
		echo "<br>";
		echo "<br>";
		echo "Place Of Birth: ".$Pobirths." ";
		echo "<br>";
		echo "<br>";
		echo "Height: ".$height." ";
		echo "<br>";
		echo "<br>";
		echo "Name of Father: ".$nofather." ";
		echo "<br>";
		echo "<br>";
		echo "Name of Mother: ".$nomother." ";
		echo "<br>";
		echo "<br>";
		echo "Address: ".$adress." ";
		echo "<br>";
		echo "<br>";
		echo "Language or Dialect Spoken:: ".$Language." ";
		echo "<br>";
		echo "<br>";
		echo "Emergency: ".$emergency." ";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "EDUCATIONAL BACKGROUND:  ";
		echo "<br>";
		echo "<br>";
		echo "Elementary: ".$elementary." ";
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "Elem. Year Graduate: ".$YEgraduate." ";
		echo "<br>";
		echo "<br>";
		echo "High School: ".$highschool." ";
		echo "<br>";
		echo "<br>";
		echo "HS Year Graduate     : ".$Yhgraduate." ";
		echo "<br>";
		echo "<br>";
		echo "College: ".$college." ";
		echo "<br>";
		echo "<br>";
		echo "College Year Graduate: ".$YCgraduate." ";
		echo "<br>";
		echo "<br>";
		echo "Course         :".$course." "."         Special Skills:".$skills;		
		echo "<br>";
		
		echo "<br>";



		
}




	  ?>


	




</body>
</html>